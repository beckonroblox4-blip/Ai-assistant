const messagesEl = document.getElementById('messages');
const userInput = document.getElementById('userInput');
const sendBtn = document.getElementById('sendBtn');

function addMessage(text, sender) {
  const div = document.createElement('div');
  div.className = `msg ${sender}`;
  div.textContent = text;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;

  addMessage(text, 'user');
  userInput.value = '';

  // Демо-жауап (кейін AI API-мен ауыстырамыз)
  setTimeout(() => {
    addMessage('Бұл демо-жауап. Келесі қадамда AI қосамыз! 🚀', 'bot');
  }, 500);
}

sendBtn.onclick = sendMessage;
userInput.addEventListener('keypress', e => {
  if (e.key === 'Enter') sendMessage();
});